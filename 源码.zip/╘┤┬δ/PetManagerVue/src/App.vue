<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
#app, html, body {
  margin: 0;
}
</style>
